#define PROGRAM_DATE     "November 2009"
#define PROGRAM_VERSION  "2009-11A"

