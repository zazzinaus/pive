#ifndef TP_DETACH_H
#define TP_DETACH_H

#include "just.h"
#include "unify.h"
#include "clause.h"

/* INTRODUCTION
*/

/* Public definitions */

/* End of public definitions */

/* Public function prototypes from detach.c */

void cond_detach(Clause major, Clause minor, void (*proc_proc) (Clause));

void cond_detach_2(Clause c1, Clause c2, void (*proc_proc) (Clause));

#endif  /* conditional compilation of whole file */
